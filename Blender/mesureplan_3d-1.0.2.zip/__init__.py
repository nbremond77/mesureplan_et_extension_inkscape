"""MesurePlan 3D — mesures dans la vue 3D de Blender : distance, distance XYZ (ΔX, ΔY, ΔZ, pente),
chaîne, surface (vraie et projetée), angle, avec accrochage, calibration et export CSV.

Extension Blender 4.2+ (blender_manifest.toml). Le bloc bl_info permet aussi
l'installation comme « addon » classique dans Blender 4.0 et 4.1.
"""

# Version de l'extension. NE PAS lire bl_info à l'exécution : pour une extension (Blender 4.2+),
# Blender retire bl_info du module après chargement (NameError constatée sous Blender 5.2).
VERSION = (1, 0, 2)

bl_info = {  # utilisé uniquement par l'installation « addon » historique (Blender 4.0 / 4.1)
    "name": "MesurePlan 3D",
    "author": "Bernard",
    "version": VERSION,
    "blender": (4, 0, 0),
    "location": "Vue 3D > Barre latérale (N) > MesurePlan",
    "description": "Mesures 3D : distance, ΔX/ΔY/ΔZ, pente, chaîne, surface, angle, calibration",
    "category": "3D View",
}

import bpy  # noqa: E402

from . import dessin, interface, operateurs, proprietes, socle  # noqa: E402

CLASSES = proprietes.CLASSES + operateurs.CLASSES + interface.CLASSES


def _desenregistrer_tout() -> None:
    """Retire tout ce qui a pu être enregistré, sans échouer (restes d'une activation ratée)."""
    dessin.desactiver()
    if hasattr(bpy.types.Scene, "mesureplan3d"):
        del bpy.types.Scene.mesureplan3d
    for classe in reversed(CLASSES):
        # Une classe enregistrée porte son propre attribut bl_rna
        if "bl_rna" in classe.__dict__:
            try:
                bpy.utils.unregister_class(classe)
            except RuntimeError:
                socle.journal.debug("Classe déjà retirée : %s", classe.__name__)


def register() -> None:
    cfg = socle.charger_configuration(__package__)
    socle.configurer_journal(__package__, cfg.get("journalisation", {}))
    socle.journal.info("Activation de MesurePlan 3D %s (Blender %s, Python %s)",
                       ".".join(map(str, VERSION)), bpy.app.version_string,
                       ".".join(map(str, __import__("sys").version_info[:3])))
    # Si une activation précédente a échoué à mi-chemin, ses classes sont encore enregistrées
    _desenregistrer_tout()
    classe_en_cours = None
    try:
        for classe in CLASSES:
            classe_en_cours = classe.__name__
            bpy.utils.register_class(classe)
        classe_en_cours = "Scene.mesureplan3d"
        bpy.types.Scene.mesureplan3d = bpy.props.PointerProperty(type=proprietes.MP3D_Reglages)
        classe_en_cours = "gestionnaire de dessin"
        dessin.activer()
    except Exception:
        # Trace complète dans le journal, puis retour à un état propre : un nouvel essai est possible
        socle.journal.exception("Échec de l'activation (étape : %s)", classe_en_cours)
        _desenregistrer_tout()
        raise
    socle.journal.info("MesurePlan 3D activé")


def unregister() -> None:
    _desenregistrer_tout()
    socle.journal.info("MesurePlan 3D désactivé")
    socle.fermer_journal()
